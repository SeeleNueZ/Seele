关于矩阵维度参考的了
https://www.zhihu.com/question/265545749?sort=created
关于DNS算法参考的
https://blog.csdn.net/wyll19980812/article/details/112599090
*其实主要是看的图

应该这个算法处理不了1*2 * 2*1这种类型的矩阵乘法？
思考ing'